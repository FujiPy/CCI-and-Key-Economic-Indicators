
# 📊 Predicting and Understanding the Consumer Confidence Index (CCI) Using Macroeconomic Indicators

**Team Members**: Max Fujimori, [Team Member 2], [Team Member 3], [Team Member 4]  
**Institution**: Lafayette College | Economics & Data Science  
**Course**: [Course Name] – Final Data Science Project  

---

## 🔗 Project Links

- 🧠 [Colab Notebook](https://github.com/FujiPy/CCI-and-Key-Economic-Indicators/blob/main/CCIMarkdown.md)
- 🎥 [Video Presentation](https://your-video-link.com)
- 🌐 [Interactive Dashboard (.io Page)](https://your-streamlit-or-pages-link.io)

---

## 📌 Project Overview

This project explores the relationship between the **Consumer Confidence Index (CCI)** and key **macroeconomic indicators** such as unemployment, inflation, GDP growth, mortgage interest rates, and household income. The goal is twofold:

1. **Analyze how current macroeconomic conditions shape consumer sentiment** using regression models.
2. **Evaluate whether CCI can serve as a leading indicator** to forecast future economic outcomes.

Using machine learning models including **polynomial regression**, **ridge regression**, and **random forests**, we quantified both coincident and forward-looking relationships between economic fundamentals and CCI. We also visualized variable trends over time and examined feature importance across models.

---

## 📈 Key Findings

- 📉 **Polynomial Ridge Regression** achieved an R² of **0.91**, indicating strong alignment between macroeconomic inputs and CCI.
- 🌲 **Random Forest Regression** outperformed linear models with an R² of **0.95** and RMSE of **6.02**, showing high predictive accuracy for current sentiment.
- 🔮 When treating **CCI as a leading indicator**, it forecasted **housing price levels** and **household income** moderately well (R² = 0.70 and 0.56), but had **low predictive power** for policy-driven variables like inflation or mortgage rates.
- 📊 Top predictive variables included **unemployment rate**, **home prices**, and **household income**, reflecting real economic conditions most visible to consumers.

---

## 🧠 Sample Visuals

### Random Forest Feature Importance  
![Feature Importance](https://github.com/FujiPy/CCI-and-Key-Economic-Indicators/blob/main/assets/feature_importance.png)

### Variable Trends Over Time  
![Time Series](https://github.com/FujiPy/CCI-and-Key-Economic-Indicators/blob/main/assets/time_series_plot.png)

---

## 🏛️ Business & Policy Application

This framework offers real value to **economic policymakers and analysts**, enabling data-driven understanding of how macro conditions influence public sentiment. It also supports **early warning systems** by examining sentiment's ability to forecast future economic realities—especially in consumer-driven sectors like housing and retail.

---

## 📦 Technologies Used

- **Python** (Pandas, scikit-learn, matplotlib, seaborn)
- **Google Colab**
- **Streamlit** (for dashboard)
- **GitHub** (for versioning & documentation)

---

## 📁 File Structure

```
├── CCIMarkdown.md               # Project walkthrough in Markdown
├── CCI_and_Indicators.ipynb     # Main Colab notebook
├── assets/                      # Visualizations for README
├── dashboard_app.py             # Streamlit dashboard code
└── README.md                    # This file
```

---

## 📬 Contact

For questions or feedback, feel free to open an issue or reach out to **Max Fujimori** via GitHub or [your email].
